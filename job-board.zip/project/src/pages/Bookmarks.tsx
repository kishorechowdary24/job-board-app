import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import JobCard from '../components/JobCard';
import { Bookmark } from 'lucide-react';

interface BookmarkData {
  id: string;
  jobId: string;
  userId: string;
  bookmarkedAt: any;
}

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  description: string;
  postedAt: any;
  recruiterId: string;
}

const Bookmarks: React.FC = () => {
  const { currentUser } = useAuth();
  const [bookmarkedJobs, setBookmarkedJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (currentUser) {
      fetchBookmarkedJobs();
    }
  }, [currentUser]);

  const fetchBookmarkedJobs = async () => {
    if (!currentUser) return;

    try {
      const q = query(
        collection(db, 'bookmarks'),
        where('userId', '==', currentUser.uid)
      );
      const querySnapshot = await getDocs(q);
      
      const bookmarksData = await Promise.all(
        querySnapshot.docs.map(async (bookmarkDoc) => {
          const bookmarkData = { id: bookmarkDoc.id, ...bookmarkDoc.data() } as BookmarkData;
          
          // Fetch job details
          const jobDoc = await getDoc(doc(db, 'jobs', bookmarkData.jobId));
          if (jobDoc.exists()) {
            return { id: jobDoc.id, ...jobDoc.data() } as Job;
          }
          return null;
        })
      );

      // Filter out null values and sort by most recently bookmarked
      const validJobs = bookmarksData.filter(job => job !== null) as Job[];
      setBookmarkedJobs(validJobs);
    } catch (error) {
      console.error('Error fetching bookmarked jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Saved Jobs</h1>
        <p className="text-gray-600">Jobs you've bookmarked for later review</p>
      </div>

      {bookmarkedJobs.length === 0 ? (
        <div className="text-center py-12">
          <Bookmark className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">No saved jobs yet</h3>
          <p className="text-gray-600">Bookmark jobs you're interested in to save them here</p>
        </div>
      ) : (
        <>
          <div className="flex items-center text-gray-600 mb-6">
            <Bookmark className="h-5 w-5 mr-2" />
            <span>{bookmarkedJobs.length} saved job{bookmarkedJobs.length !== 1 ? 's' : ''}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bookmarkedJobs.map((job) => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default Bookmarks;