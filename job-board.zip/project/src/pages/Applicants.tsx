import React, { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  where, 
  getDocs, 
  doc, 
  getDoc, 
  updateDoc 
} from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { Users, Calendar, Building, MapPin, DollarSign, Mail, User } from 'lucide-react';

interface Application {
  id: string;
  jobId: string;
  userId: string;
  appliedAt: any;
  status?: string; // ✅ Optional, to avoid crash
}

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  description: string;
  recruiterId: string;
}

interface UserData {
  uid: string;
  email: string;
  role: string;
}

interface ApplicationWithDetails extends Application {
  job: Job;
  applicant: UserData;
}

const Applicants: React.FC = () => {
  const { currentUser } = useAuth();
  const [applications, setApplications] = useState<ApplicationWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState<string | null>(null);

  useEffect(() => {
    if (currentUser) {
      fetchApplications();
    }
  }, [currentUser]);

  const fetchApplications = async () => {
    if (!currentUser) return;

    try {
      const jobsQuery = query(
        collection(db, 'jobs'),
        where('recruiterId', '==', currentUser.uid)
      );
      const jobsSnapshot = await getDocs(jobsQuery);
      const recruiterJobs = jobsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Job[];

      if (recruiterJobs.length === 0) {
        setApplications([]);
        setLoading(false);
        return;
      }

      const jobIds = recruiterJobs.map(job => job.id);
      const applicationsData: ApplicationWithDetails[] = [];

      for (const jobId of jobIds) {
        const applicationsQuery = query(
          collection(db, 'applications'),
          where('jobId', '==', jobId)
        );
        const applicationsSnapshot = await getDocs(applicationsQuery);

        for (const applicationDoc of applicationsSnapshot.docs) {
          const applicationData = {
            id: applicationDoc.id,
            ...applicationDoc.data()
          } as Application;

          const job = recruiterJobs.find(j => j.id === applicationData.jobId);
          const userDoc = await getDoc(doc(db, 'users', applicationData.userId));
          const applicant = userDoc.exists() ? userDoc.data() as UserData : null;

          if (job && applicant) {
            applicationsData.push({
              ...applicationData,
              job,
              applicant
            });
          }
        }
      }

      const sortedApplications = applicationsData.sort((a, b) => {
        const aDate = typeof a.appliedAt?.toDate === 'function' ? a.appliedAt.toDate() : new Date(a.appliedAt);
        const bDate = typeof b.appliedAt?.toDate === 'function' ? b.appliedAt.toDate() : new Date(b.appliedAt);
        return bDate.getTime() - aDate.getTime();
      });

      setApplications(sortedApplications);
    } catch (error) {
      console.error('Error fetching applications:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateApplicationStatus = async (applicationId: string, newStatus: string) => {
    setUpdatingStatus(applicationId);
    try {
      await updateDoc(doc(db, 'applications', applicationId), {
        status: newStatus
      });

      setApplications(prev =>
        prev.map(app =>
          app.id === applicationId ? { ...app, status: newStatus } : app
        )
      );
    } catch (error) {
      console.error('Error updating application status:', error);
    } finally {
      setUpdatingStatus(null);
    }
  };

  const formatDate = (date: any) => {
    if (!date) return '';
    const firebaseDate = typeof date.toDate === 'function' ? date.toDate() : new Date(date);
    return firebaseDate.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusColor = (status?: string) => {
    if (!status) return 'bg-gray-100 text-gray-800 border-gray-200';
    switch (status.toLowerCase()) {
      case 'accepted':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'in progress':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Job Applicants</h1>
        <p className="text-gray-600">Manage applications for your posted jobs</p>
      </div>

      {applications.length === 0 ? (
        <div className="text-center py-12">
          <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">No applications yet</h3>
          <p className="text-gray-600">Applications for your posted jobs will appear here</p>
        </div>
      ) : (
        <>
          <div className="flex items-center text-gray-600 mb-6">
            <Users className="h-5 w-5 mr-2" />
            <span>{applications.length} application{applications.length !== 1 ? 's' : ''}</span>
          </div>

          <div className="space-y-6">
            {applications.map((application) => (
              <div
                key={application.id}
                className="bg-white rounded-lg shadow-md border border-gray-200 p-6 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Job Details */}
                  <div className="lg:col-span-2">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">
                          {application.job.title}
                        </h3>
                        <div className="flex items-center text-gray-600 mb-2">
                          <Building className="h-4 w-4 mr-2" />
                          <span className="font-medium">{application.job.company}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-4 mb-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{application.job.location}</span>
                      </div>
                      <div className="flex items-center">
                        <DollarSign className="h-4 w-4 mr-1" />
                        <span>{application.job.salary}</span>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        <span>Applied {formatDate(application.appliedAt)}</span>
                      </div>
                    </div>

                    {/* Applicant Details */}
                    <div className="bg-gray-50 rounded-lg p-4 mb-4">
                      <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                        <User className="h-4 w-4 mr-2" />
                        Applicant Details
                      </h4>
                      <div className="flex items-center text-gray-600">
                        <Mail className="h-4 w-4 mr-2" />
                        <span>{application.applicant.email}</span>
                      </div>
                    </div>
                  </div>

                  {/* Status Management */}
                  <div className="lg:col-span-1">
                    <div className="bg-gray-50 rounded-lg p-4 h-full flex flex-col">
                      <h4 className="font-medium text-gray-900 mb-3">Application Status</h4>

                      <div className="mb-4">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(application.status)}`}>
                          {application.status ? (
                            application.status.charAt(0).toUpperCase() + application.status.slice(1).toLowerCase()
                          ) : (
                            'Unknown'
                          )}
                        </span>
                      </div>

                      <div className="space-y-2 flex-1">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Update Status:
                        </label>
                        <div className="space-y-2">
                          {['Pending', 'In Progress', 'Accepted', 'Rejected'].map((status) => (
                            <button
                              key={status}
                              onClick={() => updateApplicationStatus(application.id, status)}
                              disabled={updatingStatus === application.id || application.status === status}
                              className={`w-full text-left px-3 py-2 text-sm rounded-lg transition-colors duration-200 ${
                                application.status === status
                                  ? 'bg-blue-100 text-blue-800 cursor-not-allowed'
                                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
                              }`}
                            >
                              {updatingStatus === application.id ? 'Updating...' : status}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default Applicants;
