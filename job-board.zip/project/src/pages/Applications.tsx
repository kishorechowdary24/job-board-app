import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { FileText, Calendar, Building, MapPin, DollarSign, ChevronLeft, ChevronRight } from 'lucide-react';

interface Application {
  id: string;
  jobId: string;
  userId: string;
  appliedAt: any;
  status: string;
}

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  description: string;
}

interface ApplicationWithJob extends Application {
  job: Job;
}

const Applications: React.FC = () => {
  const { currentUser } = useAuth();
  const [applications, setApplications] = useState<ApplicationWithJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (currentUser) {
      fetchApplications();
    }
  }, [currentUser]);

  const fetchApplications = async () => {
    if (!currentUser) return;

    try {
      const q = query(
        collection(db, 'applications'),
        where('userId', '==', currentUser.uid)
      );
      const querySnapshot = await getDocs(q);
      
      const applicationsData = await Promise.all(
        querySnapshot.docs.map(async (applicationDoc) => {
          const applicationData = { id: applicationDoc.id, ...applicationDoc.data() } as Application;
          
          // Fetch job details
          const jobDoc = await getDoc(doc(db, 'jobs', applicationData.jobId));
          const jobData = jobDoc.exists() ? { id: jobDoc.id, ...jobDoc.data() } as Job : null;
          
          return {
            ...applicationData,
            job: jobData
          } as ApplicationWithJob;
        })
      );

      // Sort safely by appliedAt date (handles Firestore Timestamp or JS Date or string)
      const validApplications = applicationsData
        .filter(app => app.job !== null)
        .sort((a, b) => {
          const aDate = typeof a.appliedAt?.toDate === 'function' ? a.appliedAt.toDate() : new Date(a.appliedAt);
          const bDate = typeof b.appliedAt?.toDate === 'function' ? b.appliedAt.toDate() : new Date(b.appliedAt);
          return bDate.getTime() - aDate.getTime();
        });

      setApplications(validApplications);
    } catch (error) {
      console.error('Error fetching applications:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (date: any) => {
    if (!date) return '';
    const firebaseDate = typeof date.toDate === 'function' ? date.toDate() : new Date(date);
    return firebaseDate.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'accepted':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'in progress':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const nextApplication = () => {
    setCurrentIndex((prev) => (prev + 1) % applications.length);
  };

  const prevApplication = () => {
    setCurrentIndex((prev) => (prev - 1 + applications.length) % applications.length);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (applications.length === 0) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Applications</h1>
          <p className="text-gray-600">Track the status of your job applications</p>
        </div>
        
        <div className="text-center py-12">
          <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-900 mb-2">No applications yet</h3>
          <p className="text-gray-600">Start applying to jobs to see them here</p>
        </div>
      </div>
    );
  }

  const currentApplication = applications[currentIndex];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">My Applications</h1>
        <p className="text-gray-600">Track the status of your job applications</p>
      </div>

      {/* Application Counter */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center text-gray-600">
          <FileText className="h-5 w-5 mr-2" />
          <span>
            Application {currentIndex + 1} of {applications.length}
          </span>
        </div>

        {/* Navigation Controls */}
        {applications.length > 1 && (
          <div className="flex items-center space-x-2">
            <button
              onClick={prevApplication}
              className="p-2 rounded-lg bg-white border border-gray-300 text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors duration-200"
              aria-label="Previous application"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={nextApplication}
              className="p-2 rounded-lg bg-white border border-gray-300 text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors duration-200"
              aria-label="Next application"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        )}
      </div>

      {/* Application Card */}
      <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-8 hover:shadow-xl transition-shadow duration-300">
        <div className="flex justify-between items-start mb-6">
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-gray-900 mb-3">
              {currentApplication.job.title}
            </h2>
            <div className="flex items-center text-gray-600 mb-3">
              <Building className="h-5 w-5 mr-2" />
              <span className="font-medium text-lg">{currentApplication.job.company}</span>
            </div>
          </div>
          
          {/* Status Badge */}
          <div className="flex flex-col items-end">
            <span className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium border ${getStatusColor(currentApplication.status)}`}>
              {currentApplication.status || 'Pending'}
            </span>
            <div className="flex items-center text-sm text-gray-500 mt-2">
              <Calendar className="h-4 w-4 mr-1" />
              Applied {formatDate(currentApplication.appliedAt)}
            </div>
          </div>
        </div>

        {/* Job Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="flex items-center text-gray-600">
            <MapPin className="h-5 w-5 mr-3 text-gray-400" />
            <div>
              <span className="text-sm text-gray-500">Location</span>
              <p className="font-medium">{currentApplication.job.location}</p>
            </div>
          </div>
          <div className="flex items-center text-gray-600">
            <DollarSign className="h-5 w-5 mr-3 text-gray-400" />
            <div>
              <span className="text-sm text-gray-500">Salary</span>
              <p className="font-medium">{currentApplication.job.salary}</p>
            </div>
          </div>
        </div>

        {/* Job Description */}
        <div className="border-t border-gray-200 pt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Job Description</h3>
          <p className="text-gray-700 leading-relaxed">{currentApplication.job.description}</p>
        </div>

        {/* Application Status Timeline */}
        <div className="border-t border-gray-200 pt-6 mt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Application Status</h3>
          <div className="flex items-center space-x-4">
            <div className={`flex items-center space-x-2 ${
              currentApplication.status === 'Pending' ? 'text-gray-600' : 'text-gray-400'
            }`}>
              <div className={`w-3 h-3 rounded-full ${
                currentApplication.status === 'Pending' ? 'bg-gray-600' : 'bg-gray-300'
              }`}></div>
              <span className="text-sm font-medium">Pending</span>
            </div>
            <div className="flex-1 h-px bg-gray-300"></div>
            <div className={`flex items-center space-x-2 ${
              currentApplication.status === 'In Progress' ? 'text-yellow-600' : 'text-gray-400'
            }`}>
              <div className={`w-3 h-3 rounded-full ${
                currentApplication.status === 'In Progress' ? 'bg-yellow-600' : 'bg-gray-300'
              }`}></div>
              <span className="text-sm font-medium">In Progress</span>
            </div>
            <div className="flex-1 h-px bg-gray-300"></div>
            <div className={`flex items-center space-x-2 ${
              currentApplication.status === 'Accepted' ? 'text-green-600' : 
              currentApplication.status === 'Rejected' ? 'text-red-600' : 'text-gray-400'
            }`}>
              <div className={`w-3 h-3 rounded-full ${
                currentApplication.status === 'Accepted' ? 'bg-green-600' : 
                currentApplication.status === 'Rejected' ? 'bg-red-600' : 'bg-gray-300'
              }`}></div>
              <span className="text-sm font-medium">
                {currentApplication.status === 'Accepted' ? 'Accepted' : 
                 currentApplication.status === 'Rejected' ? 'Rejected' : 'Final Decision'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Pagination Dots */}
      {applications.length > 1 && (
        <div className="flex justify-center mt-6 space-x-2">
          {applications.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full transition-colors duration-200 ${
                index === currentIndex ? 'bg-blue-600' : 'bg-gray-300 hover:bg-gray-400'
              }`}
              aria-label={`Go to application ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Applications;