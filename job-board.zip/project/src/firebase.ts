import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Replace with your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyC7666n_l8A5ecd2vf25BS3-6bh2a5AY6U",
  authDomain: "job-search-portal-f98c3.firebaseapp.com",
  projectId: "job-search-portal-f98c3",
  storageBucket: "job-search-portal-f98c3.appspot.com",
  messagingSenderId: "197091518507",
  appId: "1:197091518507:web:54e2ab37b77b0ea26ee26e",
  measurementId: "G-5RG2FRL8ZZ"
};

// Initialize Firebase only if it hasn't been initialized already
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app);

export default app;