import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  DollarSign, 
  Building, 
  Calendar,
  Bookmark,
  BookmarkCheck,
  CheckCircle
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { 
  collection, 
  addDoc, 
  query, 
  where, 
  getDocs,
  deleteDoc,
  doc
} from 'firebase/firestore';
import { db } from '../firebase';

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  description: string;
  postedAt: any;
  recruiterId: string;
}

interface JobCardProps {
  job: Job;
}

const JobCard: React.FC<JobCardProps> = ({ job }) => {
  const { currentUser, userData } = useAuth();
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [hasApplied, setHasApplied] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (currentUser && userData?.role === 'jobseeker') {
      checkBookmarkStatus();
      checkApplicationStatus();
    }
  }, [currentUser, job.id]);

  const checkBookmarkStatus = async () => {
    if (!currentUser) return;
    
    try {
      const q = query(
        collection(db, 'bookmarks'),
        where('userId', '==', currentUser.uid),
        where('jobId', '==', job.id)
      );
      const querySnapshot = await getDocs(q);
      setIsBookmarked(!querySnapshot.empty);
    } catch (error) {
      console.error('Error checking bookmark status:', error);
    }
  };

  const checkApplicationStatus = async () => {
    if (!currentUser) return;
    
    try {
      const q = query(
        collection(db, 'applications'),
        where('userId', '==', currentUser.uid),
        where('jobId', '==', job.id)
      );
      const querySnapshot = await getDocs(q);
      setHasApplied(!querySnapshot.empty);
    } catch (error) {
      console.error('Error checking application status:', error);
    }
  };

  const handleBookmark = async () => {
    if (!currentUser || userData?.role !== 'jobseeker') return;
    
    setLoading(true);
    try {
      if (isBookmarked) {
        // Remove bookmark
        const q = query(
          collection(db, 'bookmarks'),
          where('userId', '==', currentUser.uid),
          where('jobId', '==', job.id)
        );
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach(async (document) => {
          await deleteDoc(doc(db, 'bookmarks', document.id));
        });
        setIsBookmarked(false);
      } else {
        // Add bookmark
        await addDoc(collection(db, 'bookmarks'), {
          userId: currentUser.uid,
          jobId: job.id,
          bookmarkedAt: new Date()
        });
        setIsBookmarked(true);
      }
    } catch (error) {
      console.error('Error handling bookmark:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async () => {
    if (!currentUser || userData?.role !== 'jobseeker' || hasApplied) return;
    
    setLoading(true);
    try {
      await addDoc(collection(db, 'applications'), {
        userId: currentUser.uid,
        jobId: job.id,
        appliedAt: new Date(),
        status: 'Pending' // Default status
      });
      setHasApplied(true);
    } catch (error) {
      console.error('Error applying to job:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (date: any) => {
    if (!date) return '';
    const firebaseDate = date.toDate ? date.toDate() : new Date(date);
    return firebaseDate.toLocaleDateString();
  };

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-300 border border-gray-200 hover:border-blue-300">
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">{job.title}</h3>
            <div className="flex items-center text-gray-600 mb-2">
              <Building className="h-4 w-4 mr-2" />
              <span className="font-medium">{job.company}</span>
            </div>
          </div>
          
          {userData?.role === 'jobseeker' && (
            <button
              onClick={handleBookmark}
              disabled={loading}
              className={`p-2 rounded-full transition-colors duration-200 ${
                isBookmarked
                  ? 'text-blue-600 hover:bg-blue-50'
                  : 'text-gray-400 hover:text-blue-600 hover:bg-blue-50'
              }`}
            >
              {isBookmarked ? (
                <BookmarkCheck className="h-5 w-5" />
              ) : (
                <Bookmark className="h-5 w-5" />
              )}
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-4 mb-4 text-sm text-gray-600">
          <div className="flex items-center">
            <MapPin className="h-4 w-4 mr-1" />
            <span>{job.location}</span>
          </div>
          <div className="flex items-center">
            <DollarSign className="h-4 w-4 mr-1" />
            <span>{job.salary}</span>
          </div>
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-1" />
            <span>Posted {formatDate(job.postedAt)}</span>
          </div>
        </div>

        <p className="text-gray-700 mb-6 line-clamp-3">{job.description}</p>

        {userData?.role === 'jobseeker' && (
          <div className="flex gap-3">
            <button
              onClick={handleApply}
              disabled={loading || hasApplied}
              className={`flex-1 py-2 px-4 rounded-lg font-medium transition-colors duration-200 ${
                hasApplied
                  ? 'bg-green-100 text-green-700 cursor-not-allowed'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              {loading ? (
                'Processing...'
              ) : hasApplied ? (
                <div className="flex items-center justify-center">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Already Applied
                </div>
              ) : (
                'Apply Now'
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default JobCard;