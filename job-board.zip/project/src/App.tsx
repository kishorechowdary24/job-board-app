import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import PostJob from './pages/PostJob';
import Applications from './pages/Applications';
import Bookmarks from './pages/Bookmarks';
import Applicants from './pages/Applicants';

const AppRoutes: React.FC = () => {
  const { currentUser } = useAuth();

  return (
    <Routes>
      <Route
        path="/login"
        element={currentUser ? <Navigate to="/" replace /> : <Login />}
      />
      <Route
        path="/signup"
        element={currentUser ? <Navigate to="/" replace /> : <Signup />}
      />
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route
          path="post-job"
          element={
            <ProtectedRoute requiredRole="recruiter">
              <PostJob />
            </ProtectedRoute>
          }
        />
        <Route
          path="applicants"
          element={
            <ProtectedRoute requiredRole="recruiter">
              <Applicants />
            </ProtectedRoute>
          }
        />
        <Route
          path="applications"
          element={
            <ProtectedRoute requiredRole="jobseeker">
              <Applications />
            </ProtectedRoute>
          }
        />
        <Route
          path="bookmarks"
          element={
            <ProtectedRoute requiredRole="jobseeker">
              <Bookmarks />
            </ProtectedRoute>
          }
        />
      </Route>
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}

export default App;